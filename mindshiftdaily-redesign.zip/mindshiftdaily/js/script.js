// Mobile nav toggle
document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.site-nav');

  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      const isOpen = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });
  }

  // Subscribe form: front-end only placeholder.
  // Connect this to Formspree/Getform (or similar) to actually collect emails.
  const form = document.querySelector('.subscribe-form');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const email = document.getElementById('email');
      alert(`Thanks! (Demo only — connect this form to Formspree or Getform to actually collect: ${email.value})`);
      form.reset();
    });
  }
});
