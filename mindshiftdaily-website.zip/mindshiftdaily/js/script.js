document.addEventListener('DOMContentLoaded', function () {
  var toggle = document.querySelector('.nav-toggle');
  var nav = document.querySelector('.main-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      nav.classList.toggle('open');
    });
  }

  var newsForm = document.querySelector('.news-form');
  if (newsForm) {
    newsForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var input = newsForm.querySelector('input[type="email"]');
      if (input && input.value) {
        newsForm.innerHTML = '<p style="color:#fff;font-weight:600;">Thanks — you\'re on the list. Check your inbox to confirm.</p>';
      }
    });
  }

  var contactForm = document.querySelector('.contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', function (e) {
      e.preventDefault();
      contactForm.innerHTML = '<p style="font-weight:600;color:#1F4D3D;">Thanks for reaching out — we reply within 2 business days.</p>';
    });
  }
});
